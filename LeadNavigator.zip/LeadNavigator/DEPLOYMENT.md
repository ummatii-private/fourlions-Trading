# 🚀 Deployment Guide - Fourlions Trading Website

This guide provides detailed instructions for deploying the Fourlions Trading website to various platforms.

## 📋 Pre-deployment Checklist

- [ ] All environment variables are configured
- [ ] SendGrid account is set up and verified
- [ ] Domain (if using custom domain) is ready
- [ ] SSL certificates are configured (handled automatically by most platforms)

## 🔧 Environment Setup

### Required Environment Variables

```bash
# Essential for contact form functionality
SENDGRID_API_KEY=SG.your_sendgrid_api_key_here

# Session security
SESSION_SECRET=your_secure_random_string_here

# Environment mode  
NODE_ENV=production
```

### Optional Environment Variables

```bash
# Custom port (default: 5000)
PORT=3000

# Database URL (if using external database)
DATABASE_URL=postgresql://username:password@host:port/database
```

## 🌍 Platform-Specific Deployment

### 1. Railway (Recommended for Full-Stack Apps)

**Automatic Deployment:**
1. Connect your GitHub repository to Railway
2. Set environment variables in Railway dashboard
3. Railway automatically detects Node.js apps and configures deployment

**Configuration:**
- Railway will automatically run `npm install` and `npm run start`
- No additional configuration needed
- Built-in PostgreSQL available if needed

### 2. Render

**Deployment Steps:**
1. Connect GitHub repository to Render
2. Create a new Web Service
3. Configure build and start commands:
   ```
   Build Command: npm install && npm run build
   Start Command: npm run start
   ```
4. Set environment variables in Render dashboard

### 3. Vercel (Advanced - Requires Restructuring)

⚠️ **Note**: This Express+Vite app requires restructuring for Vercel serverless functions. Consider Railway or Render for easier deployment.

### 4. Heroku

**Deployment Steps:**
```bash
# Install Heroku CLI
# Create Heroku app
heroku create fourlions-trading

# Set environment variables
heroku config:set SENDGRID_API_KEY=your_key
heroku config:set SESSION_SECRET=your_secret
heroku config:set NODE_ENV=production

# Deploy
git push heroku main
```

**Procfile:**
```
web: npm run start
```

### 5. DigitalOcean App Platform

**Deployment Steps:**
1. Connect GitHub repository
2. Configure build settings:
   ```
   Build Command: npm run build
   Run Command: npm run start
   ```
3. Set environment variables in the control panel

### 6. Self-Hosted (VPS/Dedicated Server)

**Server Setup:**
```bash
# Install Node.js 20+
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Install nginx for reverse proxy
sudo apt update
sudo apt install nginx
```

**Application Deployment:**
```bash
# Clone repository
git clone https://github.com/your-username/fourlions-trading.git
cd fourlions-trading

# Install dependencies
npm install

# Build application
npm run build

# Start with PM2
pm2 start ecosystem.config.js
pm2 startup
pm2 save
```

**PM2 Configuration (ecosystem.config.js):**
```javascript
module.exports = {
  apps: [{
    name: 'fourlions-trading',
    script: 'dist/index.js',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 'max',
    exec_mode: 'cluster'
  }]
}
```

**Nginx Configuration:**
```nginx
server {
    listen 80;
    server_name fourlionstrading.com www.fourlionstrading.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📧 SendGrid Setup for Production

### Domain Authentication (Recommended)

1. **Add Domain Authentication:**
   - Go to SendGrid Settings > Sender Authentication
   - Add your domain (fourlionstrading.com)
   - Add the provided DNS records to your domain

2. **Update Email Configuration:**
   ```typescript
   // In server/emailService.ts
   from: 'leads@fourlionstrading.com'  // Use verified domain
   ```

### Single Sender Verification (Alternative)

1. **Verify Sender Email:**
   - Go to SendGrid Settings > Sender Authentication
   - Verify info@fourlionstrading.com
   - Use this as the 'from' address

## 🔍 Health Checks and Monitoring

### Health Check Endpoint

Add to `server/routes.ts`:
```typescript
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version 
  });
});
```

### Monitoring Setup

**Basic Monitoring:**
```bash
# PM2 monitoring
pm2 monit

# View logs
pm2 logs fourlions-trading

# Restart application
pm2 restart fourlions-trading
```

**Advanced Monitoring:**
- Use services like New Relic, DataDog, or Sentry
- Set up uptime monitoring with services like Pingdom or StatusPage

## 🔒 Security Considerations

### Production Security Checklist

- [ ] Strong SESSION_SECRET (64+ characters)
- [ ] HTTPS enabled (SSL/TLS certificates)
- [ ] Environment variables secured
- [ ] Regular security updates
- [ ] Rate limiting implemented
- [ ] CORS properly configured
- [ ] Headers security middleware

### Security Headers

Add to Express app:
```typescript
import helmet from 'helmet';
app.use(helmet());
```

## 📊 Performance Optimization

### CDN Setup
- Use CloudFlare or AWS CloudFront for static assets
- Enable compression and caching

### Database Optimization
- If scaling beyond in-memory storage, consider PostgreSQL or MongoDB
- Implement connection pooling
- Add database indexes for frequently queried fields

### Caching Strategy
- Implement Redis for session storage
- Cache API responses where appropriate
- Use browser caching for static assets

## 🛟 Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Find and kill process using port 5000
   sudo lsof -ti:5000 | xargs sudo kill -9
   ```

2. **Email Not Sending**
   - Verify SendGrid API key is correct
   - Check sender authentication is set up
   - Review SendGrid activity logs

3. **Build Failures**
   - Ensure Node.js version compatibility (20+)
   - Clear node_modules and reinstall
   - Check for TypeScript compilation errors

4. **Memory Issues**
   - Increase server memory allocation
   - Implement database instead of in-memory storage
   - Monitor memory usage with tools like htop

### Debug Commands

```bash
# Check application logs
npm run dev  # Development mode with detailed logs

# Test email functionality
curl -X POST http://localhost:5000/api/leads \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User", 
    "company": "Test Company",
    "email": "test@example.com",
    "country": "GB",
    "products": ["rice"]
  }'
```

## 📞 Support

For deployment issues or questions:
- Check the main README.md for basic setup
- Review application logs for error details
- Test locally before deploying to production
- Verify all environment variables are set correctly

---

**Deployment prepared for Fourlions Trading Limited**  
*Last updated: Current Date*