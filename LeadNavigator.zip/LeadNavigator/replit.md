# Overview

Fourlions Trading Limited is a corporate website for a UK-based sole proprietorship specializing in international trade of premium rice, spices, coconuts, textiles, and eco-friendly cutlery. The application is a full-stack web solution designed for lead generation and business showcase, featuring a modern React frontend with Express.js backend.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent, professional design
- **Routing**: Wouter lightweight router for client-side navigation
- **State Management**: React Query for server state management and caching
- **Forms**: React Hook Form with Zod validation for robust form handling
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with TypeScript for consistency across the stack
- **Framework**: Express.js with middleware for logging, JSON parsing, and error handling
- **Validation**: Zod schemas for request validation and type inference
- **Storage**: In-memory storage for development (with Drizzle ORM configured for PostgreSQL)
- **Session Management**: Express sessions with PostgreSQL session store support

## Database Design
- **ORM**: Drizzle with PostgreSQL dialect
- **Tables**: Users table for authentication, Leads table for contact form submissions
- **Schema**: Shared TypeScript types between frontend and backend using Zod

## Form Processing & Lead Generation
- **Contact Form**: Multi-step lead capture with company details, product selection, and requirements
- **Validation**: Client-side and server-side validation using shared schemas
- **Storage**: Leads stored in database with automatic email notifications

## File Structure
- **Monorepo**: Frontend (`client/`), backend (`server/`), and shared types (`shared/`)
- **Asset Management**: Static assets in `attached_assets/` with Vite alias configuration
- **Component Organization**: UI components, pages, hooks, and utilities properly separated

## Development & Production Setup
- **Development**: Concurrent frontend and backend with hot module replacement
- **Build Process**: Vite for frontend bundling, esbuild for backend compilation
- **Process Management**: PM2 ecosystem configuration for production deployment
- **Health Monitoring**: Health check endpoint for service monitoring

# External Dependencies

## Email Service
- **SendGrid**: Email API for sending lead notifications to info@fourlionstrading.com
- **Configuration**: Requires SENDGRID_API_KEY environment variable
- **Fallback**: Graceful degradation when email service unavailable

## UI Components
- **Radix UI**: Headless component primitives for accessibility and functionality
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Type-safe component variant management

## Database Options
- **PostgreSQL**: Primary database with Drizzle ORM support
- **Neon Database**: Cloud PostgreSQL option for serverless deployments
- **Session Storage**: PostgreSQL-backed session management

## Development Tools
- **TypeScript**: Full-stack type safety
- **Tailwind CSS**: Utility-first styling framework
- **PostCSS**: CSS processing with autoprefixer
- **ESLint/Prettier**: Code quality and formatting (implied by modern setup)

## Deployment Platforms
- **Railway**: Recommended platform with automatic Node.js detection
- **Vercel/Netlify**: Alternative deployment options
- **VPS/Dedicated**: PM2 ecosystem for traditional server deployment