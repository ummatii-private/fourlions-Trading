# Fourlions Trading Limited - Corporate Website

A professional, responsive corporate website for Fourlions Trading Limited, a sole proprietorship specializing in international trade of premium rice, spices, coconuts, textiles, and eco-friendly cutlery.

## 🌟 Features

- **Responsive Design**: Mobile-first approach with modern UI components
- **Professional Navigation**: Multi-page structure with smooth navigation
- **Product Showcase**: High-quality product images and detailed descriptions
- **Lead Generation**: Integrated contact form with email notifications
- **Email Integration**: Automatic notifications to info@fourlionstrading.com
- **Modern Stack**: Built with React, TypeScript, Tailwind CSS, and Express.js
- **SEO Ready**: Optimized for search engines with proper meta tags

## 🏗 Architecture

### Frontend (React + Vite)
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **Routing**: Wouter (lightweight React router)
- **State Management**: React Query for server state
- **Forms**: React Hook Form with Zod validation

### Backend (Express.js)
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js
- **Validation**: Zod schemas
- **Storage**: In-memory storage (development)
- **Email**: SendGrid integration

## 📁 Project Structure

```
fourlions-trading/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── lib/           # Utilities and configurations
│   │   └── hooks/         # Custom React hooks
├── server/                # Express backend
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # Data storage layer
│   └── emailService.ts   # Email functionality
├── shared/               # Shared types and schemas
└── attached_assets/      # Static assets and images
```

## 🚀 Quick Start

### Prerequisites

- Node.js 20 or higher
- npm or yarn package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/fourlions-trading.git
   cd fourlions-trading
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` file with your configuration:
   ```env
   # Required for email functionality
   SENDGRID_API_KEY=your_sendgrid_api_key_here
   
   # Session secret (generate a secure random string)
   SESSION_SECRET=your_secure_session_secret_here
   
   # Environment
   NODE_ENV=development
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:5000`

## 📧 Email Configuration

The website uses SendGrid for sending contact form notifications to info@fourlionstrading.com.

### Setting up SendGrid

1. **Create a SendGrid account** at [sendgrid.com](https://sendgrid.com)
2. **Generate API Key**:
   - Go to Settings > API Keys
   - Create new API key with "Full Access" permissions
   - Copy the API key

3. **Configure sender authentication**:
   - Go to Settings > Sender Authentication
   - Verify your domain or single sender email
   - Use the verified email as the "from" address in `emailService.ts`

4. **Update environment variables**:
   ```env
   SENDGRID_API_KEY=SG.your_actual_api_key_here
   ```

## 📋 Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run check` - Run TypeScript type checking

## 🌐 Pages

1. **Home** (`/`) - Hero section with call-to-action
2. **Overview** (`/overview`) - Company information and values  
3. **Products** (`/products`) - Product catalog with images
4. **Vision & Mission** (`/vision`) - Company vision, mission, and objectives
5. **Licensing** (`/licensing`) - Sole proprietorship and compliance details
6. **Leadership** (`/leadership`) - CEO profile and team values
7. **Contact** (`/contact`) - Contact form and business information

## 🎨 Design System

The website uses a modern design system with:

- **Colors**: Professional blue and green palette
- **Typography**: Inter font family for modern readability
- **Components**: shadcn/ui component library
- **Icons**: Lucide React icon library
- **Responsive**: Mobile-first responsive design

## 📱 Mobile Responsiveness

The website is fully responsive with:
- Mobile navigation hamburger menu
- Responsive grid layouts
- Touch-friendly interactive elements
- Optimized images for all screen sizes

## 🛡 Security

- Input validation with Zod schemas
- CSRF protection with session middleware
- Secure email handling
- Environment variable protection

## 🚀 Deployment Options

### Option 1: Replit (Recommended for Development)

1. Import repository to Replit
2. Set environment variables in Replit Secrets
3. Run `npm install` and `npm run dev`

### Option 2: Railway (Recommended for Production)

1. **Deploy to Railway**:
   - Connect GitHub repository to Railway
   - Set environment variables in Railway dashboard
   - Railway auto-detects and deploys Node.js apps

### Option 3: Render

1. **Deploy to Render**:
   - Connect GitHub repository
   - Configure build command: `npm run build`
   - Configure start command: `npm run start`
   - Set environment variables in Render dashboard

### Option 4: Heroku

1. **Create Heroku app**:
   ```bash
   heroku create fourlions-trading
   ```

2. **Set environment variables**:
   ```bash
   heroku config:set SENDGRID_API_KEY=your_key_here
   heroku config:set SESSION_SECRET=your_session_secret
   ```

3. **Deploy**:
   ```bash
   git push heroku main
   ```

### Option 5: Digital Ocean/AWS/Other VPS

1. **Server setup**:
   ```bash
   # Install Node.js and PM2
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   sudo npm install -g pm2
   ```

2. **Deploy application**:
   ```bash
   # Clone repository
   git clone https://github.com/your-username/fourlions-trading.git
   cd fourlions-trading
   
   # Install dependencies
   npm install
   
   # Build for production
   npm run build
   
   # Start with PM2
   pm2 start ecosystem.config.js
   ```

## 🔧 Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `SENDGRID_API_KEY` | SendGrid API key for email functionality | Yes | - |
| `SESSION_SECRET` | Secret for session encryption | Yes | - |
| `NODE_ENV` | Environment mode | No | `development` |
| `PORT` | Server port | No | `5000` |

## 📞 Contact Information

**Fourlions Trading**
- **Email**: info@fourlionstrading.com
- **Phone**: +44 7341698712
- **Location**: London, United Kingdom
- **Owner**: Sriram Padmanabhan Kannan (CEO & Director)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is proprietary software owned by Fourlions Trading. All rights reserved.

## 🛠 Technical Support

For technical issues or questions about the website implementation:

1. **Check the issues** - Look for similar problems in GitHub issues
2. **Environment setup** - Ensure all environment variables are correctly set
3. **Dependencies** - Run `npm install` to ensure all packages are installed
4. **Logs** - Check browser console and server logs for error details

## 🔍 SEO Features

- Semantic HTML structure
- Meta descriptions for all pages
- Open Graph tags for social sharing
- Responsive images with proper alt text
- Fast loading with optimized assets
- Mobile-first responsive design

---

**Built with ❤️ for Fourlions Trading Limited**