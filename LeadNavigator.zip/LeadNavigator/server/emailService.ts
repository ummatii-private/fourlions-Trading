// SendGrid integration for sending lead notifications to info@fourlionstrading.com
import { MailService } from '@sendgrid/mail';
import type { Lead } from '@shared/schema';

const mailService = new MailService();

// Initialize SendGrid if API key is available
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.log('SendGrid API key not configured, email not sent:', params.subject);
    return false;
  }

  try {
    const emailData: any = {
      to: params.to,
      from: params.from,
      subject: params.subject,
    };

    if (params.text) {
      emailData.text = params.text;
    }
    if (params.html) {
      emailData.html = params.html;
    }

    await mailService.send(emailData);
    console.log('Email sent successfully to:', params.to);
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendLeadNotification(lead: Lead): Promise<boolean> {
  const emailContent = createLeadEmailContent(lead);
  
  return await sendEmail({
    to: 'info@fourlionstrading.com',
    from: 'leads@fourlionstrading.com', // This should be a verified sender in SendGrid
    subject: `New Lead: ${lead.company} - ${lead.firstName} ${lead.lastName}`,
    text: emailContent.text,
    html: emailContent.html
  });
}

function createLeadEmailContent(lead: Lead): { text: string; html: string } {
  const productsOfInterest = Array.isArray(lead.products) ? lead.products.join(', ') : 'None specified';
  
  const text = `
New Lead Submission - Fourlions Trading Limited

Contact Information:
- Name: ${lead.firstName} ${lead.lastName}
- Company: ${lead.company}
- Email: ${lead.email}
- Phone: ${lead.phone || 'Not provided'}
- Country: ${lead.country}

Business Details:
- Products of Interest: ${productsOfInterest}
- Estimated Monthly Volume: ${lead.volume || 'Not specified'}
- Additional Requirements: ${lead.message || 'None provided'}

Submitted: ${lead.createdAt.toLocaleString()}
Lead ID: ${lead.id}

Please follow up with this potential client as soon as possible.
  `.trim();

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f9fa;">
      <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h1 style="color: #1e40af; margin-bottom: 20px; border-bottom: 2px solid #1e40af; padding-bottom: 10px;">
          New Lead Submission
        </h1>
        
        <div style="background-color: #f1f5f9; padding: 15px; border-radius: 6px; margin-bottom: 20px;">
          <p style="margin: 0; font-size: 16px; font-weight: bold; color: #334155;">
            Fourlions Trading Limited - Lead Notification
          </p>
        </div>

        <h2 style="color: #475569; font-size: 18px; margin-bottom: 15px;">Contact Information</h2>
        <table style="width: 100%; margin-bottom: 20px; border-collapse: collapse;">
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b; width: 30%;">Name:</td>
            <td style="padding: 8px 0; color: #1e293b;">${lead.firstName} ${lead.lastName}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b;">Company:</td>
            <td style="padding: 8px 0; color: #1e293b;">${lead.company}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b;">Email:</td>
            <td style="padding: 8px 0; color: #1e293b;"><a href="mailto:${lead.email}" style="color: #1e40af;">${lead.email}</a></td>
          </tr>
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b;">Phone:</td>
            <td style="padding: 8px 0; color: #1e293b;">${lead.phone || 'Not provided'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b;">Country:</td>
            <td style="padding: 8px 0; color: #1e293b;">${lead.country}</td>
          </tr>
        </table>

        <h2 style="color: #475569; font-size: 18px; margin-bottom: 15px;">Business Details</h2>
        <table style="width: 100%; margin-bottom: 20px; border-collapse: collapse;">
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b; width: 30%; vertical-align: top;">Products of Interest:</td>
            <td style="padding: 8px 0; color: #1e293b;">${productsOfInterest}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b; vertical-align: top;">Monthly Volume:</td>
            <td style="padding: 8px 0; color: #1e293b;">${lead.volume || 'Not specified'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; font-weight: bold; color: #64748b; vertical-align: top;">Additional Requirements:</td>
            <td style="padding: 8px 0; color: #1e293b;">${lead.message || 'None provided'}</td>
          </tr>
        </table>

        <div style="background-color: #f8fafc; padding: 15px; border-radius: 6px; margin-top: 20px;">
          <p style="margin: 0; font-size: 14px; color: #64748b;">
            <strong>Submitted:</strong> ${lead.createdAt.toLocaleString()}<br>
            <strong>Lead ID:</strong> ${lead.id}
          </p>
        </div>

        <div style="margin-top: 25px; padding: 15px; background-color: #dbeafe; border-radius: 6px; border-left: 4px solid #1e40af;">
          <p style="margin: 0; font-size: 14px; color: #1e40af; font-weight: bold;">
            📧 Please follow up with this potential client as soon as possible.
          </p>
        </div>
      </div>
    </div>
  `;

  return { text, html };
}