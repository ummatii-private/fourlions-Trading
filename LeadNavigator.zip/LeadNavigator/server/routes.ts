import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertLeadSchema } from "@shared/schema";
import { sendLeadNotification } from "./emailService";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get('/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      service: 'fourlions-trading-website'
    });
  });

  // Lead generation endpoints
  app.post("/api/leads", async (req, res) => {
    try {
      const leadData = insertLeadSchema.parse(req.body);
      const lead = await storage.createLead(leadData);
      
      // Send email notification to info@fourlionstrading.com
      try {
        const emailSent = await sendLeadNotification(lead);
        console.log(`Lead email notification ${emailSent ? 'sent' : 'failed'} for lead ${lead.id}`);
      } catch (emailError) {
        console.error('Failed to send lead notification email:', emailError);
        // Continue even if email fails - don't block lead creation
      }
      
      res.json({ success: true, lead });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: "Internal server error" 
        });
      }
    }
  });

  app.get("/api/leads", async (req, res) => {
    try {
      const leads = await storage.getLeads();
      res.json({ success: true, leads });
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch leads" 
      });
    }
  });

  app.get("/api/leads/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const lead = await storage.getLeadById(id);
      
      if (!lead) {
        res.status(404).json({ 
          success: false, 
          message: "Lead not found" 
        });
        return;
      }
      
      res.json({ success: true, lead });
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: "Failed to fetch lead" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
