// PM2 ecosystem configuration for Fourlions Trading Website
// Used for production deployment on VPS/dedicated servers

module.exports = {
  apps: [{
    name: 'fourlions-trading',
    script: 'dist/index.js',
    cwd: './',
    
    // Environment configuration
    env: {
      NODE_ENV: 'development',
      PORT: 5000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    
    // Process management
    instances: 1, // Start with 1 instance, scale as needed
    exec_mode: 'fork',
    
    // Restart configuration
    watch: false, // Don't watch files in production
    max_memory_restart: '1G',
    
    // Logging
    log_file: './logs/combined.log',
    out_file: './logs/out.log',
    error_file: './logs/error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    
    // Advanced PM2 features
    min_uptime: '10s',
    max_restarts: 5,
    
    // PM2 will monitor the process automatically
    // Health endpoint available at /health for external monitoring
  }],

  // Deployment configuration
  deploy: {
    production: {
      user: 'deploy',
      host: ['your-server-ip'],
      ref: 'origin/main',
      repo: 'https://github.com/your-username/fourlions-trading.git',
      path: '/var/www/fourlions-trading',
      'post-deploy': 'npm install && npm run build && pm2 reload ecosystem.config.js --env production && pm2 save'
    }
  }
};