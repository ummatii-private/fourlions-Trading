import { Card } from "@/components/ui/card";
import { Building, Award, ShieldCheck, Table, Scale, TrendingUp, Handshake } from "lucide-react";

const Licensing = () => {
  const businessStructure = [
    {
      icon: Scale,
      title: "Direct Control",
      description: "Complete authority and direct decision-making for all business operations"
    },
    {
      icon: TrendingUp,
      title: "Agile Operations",
      description: "Quick adaptation to market changes and flexible business strategies"
    },
    {
      icon: Handshake,
      title: "Personal Relationships",
      description: "Direct engagement with clients building trust and long-term partnerships"
    }
  ];

  return (
    <section className="pt-20 pb-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-page-title">
            Licensing & Sole Proprietorship
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Legally compliant sole proprietorship structured for agile international trading
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {/* Company Registration */}
          <Card className="p-6 border border-border" data-testid="card-company-registration">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <Building className="text-primary text-xl" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-3" data-testid="text-registration-title">
              Business Registration
            </h2>
            <p className="text-muted-foreground mb-4" data-testid="text-registration-description">
              Fourlions Trading operates as a registered sole proprietorship with proper business registration and tax compliance in the UK.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status:</span>
                <span className="text-accent font-medium" data-testid="text-status">Active</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Location:</span>
                <span className="text-foreground" data-testid="text-location">London, UK</span>
              </div>
            </div>
          </Card>

          {/* Trading Licenses */}
          <Card className="p-6 border border-border" data-testid="card-trading-licenses">
            <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
              <Award className="text-secondary text-xl" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-3" data-testid="text-trading-title">
              International Trading
            </h2>
            <p className="text-muted-foreground mb-4" data-testid="text-trading-description">
              Authorized for import-export operations with proper licensing and compliance.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Import License:</span>
                <span className="text-accent font-medium" data-testid="text-import-license">Authorized</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Export License:</span>
                <span className="text-accent font-medium" data-testid="text-export-license">Authorized</span>
              </div>
            </div>
          </Card>

          {/* Compliance & Standards */}
          <Card className="p-6 border border-border" data-testid="card-compliance">
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
              <ShieldCheck className="text-accent text-xl" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-3" data-testid="text-compliance-title">
              Quality Compliance
            </h2>
            <p className="text-muted-foreground mb-4" data-testid="text-compliance-description">
              Adherent to international quality standards and trading regulations.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">ISO Standards:</span>
                <span className="text-accent font-medium" data-testid="text-iso-standards">Compliant</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Food Safety:</span>
                <span className="text-accent font-medium" data-testid="text-food-safety">Certified</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Business Structure */}
        <Card className="p-6 border border-border" data-testid="card-business-structure">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
            <Table className="text-primary text-xl" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-3" data-testid="text-structure-title">
            Sole Proprietorship Structure
          </h2>
          <p className="text-muted-foreground mb-6" data-testid="text-structure-description">
            Fourlions Trading operates as a sole proprietorship under the direct ownership and management of Sriram Padmanabhan Kannan, providing flexibility and direct decision-making for international trading operations.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6">
            {businessStructure.map((item, index) => (
              <div 
                key={index}
                className="text-center p-4 bg-muted rounded-lg"
                data-testid={`card-structure-item-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <item.icon className="text-primary text-2xl mb-2 mx-auto" />
                <h3 className="font-semibold text-foreground mb-1" data-testid={`text-structure-item-title-${index}`}>
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground" data-testid={`text-structure-item-description-${index}`}>
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Licensing;
