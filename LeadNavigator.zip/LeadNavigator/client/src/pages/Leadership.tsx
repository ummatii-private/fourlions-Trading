import { Card } from "@/components/ui/card";
import { Lightbulb, Globe, Rocket, Users, GraduationCap, Heart } from "lucide-react";
import ceoImage from "@assets/1758128009061_1758354311258.jpg";

const Leadership = () => {
  const principles = [
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Driving innovative solutions in international trading and supply chain management"
    },
    {
      icon: Globe,
      title: "Global Vision",
      description: "Understanding diverse international markets and cultural business practices"
    },
    {
      icon: Rocket,
      title: "Strategic Growth",
      description: "Focused on sustainable expansion and long-term partnership development"
    }
  ];

  const teamValues = [
    {
      icon: Users,
      title: "Diverse Expertise",
      description: "International trade, logistics, quality control, and market analysis specialists"
    },
    {
      icon: GraduationCap,
      title: "Continuous Learning",
      description: "Ongoing training in international regulations, market trends, and best practices"
    },
    {
      icon: Heart,
      title: "Shared Values",
      description: "Team members aligned with our commitment to integrity, excellence, and sustainability"
    }
  ];

  return (
    <section className="pt-20 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-page-title">
            Leadership & Talent
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Experienced leadership driving growth and innovation in international trading
          </p>
        </div>

        {/* CEO Spotlight */}
        <div className="max-w-4xl mx-auto mb-16">
          <Card className="p-8 border border-border shadow-lg" data-testid="card-ceo">
            <div className="grid md:grid-cols-3 gap-8 items-center">
              <div className="text-center">
                <img 
                  src={ceoImage}
                  alt="Sriram Padmanabhan Kannan, CEO & Director"
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover border-4 border-primary/20"
                  data-testid="img-ceo"
                />
                <h2 className="text-xl font-bold text-foreground" data-testid="text-ceo-name">
                  Sriram Padmanabhan Kannan
                </h2>
                <p className="text-primary font-medium" data-testid="text-ceo-title">
                  Chief Executive Officer & Director
                </p>
              </div>
              <div className="md:col-span-2">
                <p className="text-muted-foreground text-lg leading-relaxed mb-4" data-testid="text-ceo-description">
                  Under the leadership of Sriram Padmanabhan Kannan, Fourlions Trading Limited is guided by strong governance and a forward-looking approach. With a steadfast commitment to trust, integrity, and excellence, the leadership team drives the vision of connecting markets and fostering sustainable growth opportunities for global partners.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-muted rounded-lg" data-testid="card-experience">
                    <div className="text-2xl font-bold text-primary" data-testid="text-experience-years">10+</div>
                    <div className="text-sm text-muted-foreground">Years Experience</div>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg" data-testid="card-partners">
                    <div className="text-2xl font-bold text-secondary" data-testid="text-partners-count">50+</div>
                    <div className="text-sm text-muted-foreground">Global Partners</div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Leadership Principles */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center text-foreground mb-8" data-testid="text-principles-title">
            Leadership Principles
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {principles.map((principle, index) => (
              <div 
                key={index}
                className="text-center"
                data-testid={`card-principle-${principle.title.toLowerCase()}`}
              >
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <principle.icon className="text-primary text-2xl" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2" data-testid={`text-principle-title-${index}`}>
                  {principle.title}
                </h3>
                <p className="text-muted-foreground" data-testid={`text-principle-description-${index}`}>
                  {principle.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Team Development */}
        <Card className="bg-muted p-8" data-testid="card-team-development">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-4" data-testid="text-team-title">
              Building a Global Team
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="text-team-description">
              As we expand internationally, we're committed to building a diverse, talented team that shares our values and vision for global trading excellence.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {teamValues.map((value, index) => (
              <Card 
                key={index}
                className="p-6 text-center border border-border"
                data-testid={`card-team-value-${value.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <value.icon className="text-3xl mb-3 mx-auto" />
                <h3 className="font-semibold text-foreground mb-2" data-testid={`text-team-value-title-${index}`}>
                  {value.title}
                </h3>
                <p className="text-sm text-muted-foreground" data-testid={`text-team-value-description-${index}`}>
                  {value.description}
                </p>
              </Card>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Leadership;
