import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Leaf, Globe, Sprout, Building, Recycle, Plus } from "lucide-react";
import riceImage from "@assets/stock_images/premium_rice_grains__f7c1ba68.jpg";
import spicesImage from "@assets/stock_images/colorful_ground_spic_98c84eb4.jpg";
import coconutsImage from "@assets/stock_images/fresh_coconuts_tropi_7d942d5b.jpg";
import textilesImage from "@assets/stock_images/quality_textile_fabr_8dd427c1.jpg";
import cutleryImage from "@assets/stock_images/eco_friendly_wooden__9b61a8fa.jpg";

const Products = () => {
  const products = [
    {
      title: "Premium Rice",
      description: "High-quality rice varieties sourced from trusted producers, delivering exceptional taste and nutrition.",
      image: riceImage,
      icon: Leaf,
      badge: "Organic & Traditional Varieties",
      badgeColor: "text-primary"
    },
    {
      title: "Authentic Spices",
      description: "A wide range of authentic spices, delivering rich flavours and freshness to international markets.",
      image: spicesImage,
      icon: Globe,
      badge: "Global Flavors & Aromas",
      badgeColor: "text-primary"
    },
    {
      title: "Coconuts & Derivatives",
      description: "Fresh coconuts and related products for both food and industrial purposes, sourced sustainably.",
      image: coconutsImage,
      icon: Sprout,
      badge: "Sustainable Sourcing",
      badgeColor: "text-primary"
    },
    {
      title: "Quality Textiles",
      description: "Durable and diverse fabrics to meet varied wholesale requirements across global markets.",
      image: textilesImage,
      icon: Building,
      badge: "Industrial & Fashion Grade",
      badgeColor: "text-primary"
    },
    {
      title: "Eco-friendly Cutlery",
      description: "Sustainable, biodegradable wooden cutlery supporting global moves towards plastic-free alternatives.",
      image: cutleryImage,
      icon: Recycle,
      badge: "100% Biodegradable",
      badgeColor: "text-accent"
    }
  ];

  return (
    <section className="pt-20 pb-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-page-title">
            Our Products
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Premium quality products sourced from trusted producers worldwide
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <Card 
              key={index}
              className="overflow-hidden shadow-lg border border-border card-hover"
              data-testid={`card-product-${product.title.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <img 
                src={product.image}
                alt={product.title}
                className="w-full h-48 object-cover"
                data-testid={`img-product-${index}`}
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-2" data-testid={`text-product-title-${index}`}>
                  {product.title}
                </h3>
                <p className="text-muted-foreground mb-4" data-testid={`text-product-description-${index}`}>
                  {product.description}
                </p>
                <div className={`flex items-center text-sm ${product.badgeColor}`}>
                  <product.icon className="mr-2 h-4 w-4" />
                  <span data-testid={`text-product-badge-${index}`}>{product.badge}</span>
                </div>
              </div>
            </Card>
          ))}

          {/* Custom Solutions Card */}
          <Card className="bg-gradient-to-br from-primary to-accent text-white p-6 card-hover" data-testid="card-custom-solutions">
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
              <Plus className="text-white text-xl" />
            </div>
            <h3 className="text-xl font-bold mb-2" data-testid="text-custom-title">Custom Solutions</h3>
            <p className="text-blue-100 mb-4" data-testid="text-custom-description">
              Looking for specific products? We specialize in sourcing custom requirements for wholesalers worldwide.
            </p>
            <Link href="/contact">
              <Button 
                className="bg-white text-primary hover:bg-gray-100 transition-colors"
                data-testid="button-contact-custom"
              >
                Contact Us
              </Button>
            </Link>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Products;
