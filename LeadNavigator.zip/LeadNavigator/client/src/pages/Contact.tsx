import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertLeadSchema, type InsertLead } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, Mail, Clock, Check, File } from "lucide-react";

const Contact = () => {
  const [showSuccess, setShowSuccess] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertLead>({
    resolver: zodResolver(insertLeadSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      company: "",
      email: "",
      phone: "",
      country: "",
      products: [],
      volume: "",
      message: "",
    },
  });

  const createLeadMutation = useMutation({
    mutationFn: async (data: InsertLead) => {
      const response = await apiRequest("POST", "/api/leads", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      setShowSuccess(true);
      form.reset();
      toast({
        title: "Success!",
        description: "Your request has been submitted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit your request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertLead) => {
    createLeadMutation.mutate(data);
  };

  const countries = [
    { value: "IN", label: "India" },
    { value: "AE", label: "United Arab Emirates" },
    { value: "SA", label: "Saudi Arabia" },
    { value: "MY", label: "Malaysia" },
    { value: "SG", label: "Singapore" },
    { value: "KE", label: "Kenya" },
    { value: "NG", label: "Nigeria" },
    { value: "ZA", label: "South Africa" },
    { value: "GB", label: "United Kingdom" },
    { value: "DE", label: "Germany" },
    { value: "FR", label: "France" },
    { value: "US", label: "United States" },
    { value: "CA", label: "Canada" },
    { value: "other", label: "Other" },
  ];

  const products = [
    { id: "rice", label: "Rice" },
    { id: "spices", label: "Spices" },
    { id: "coconuts", label: "Coconuts" },
    { id: "textiles", label: "Textiles" },
    { id: "cutlery", label: "Eco-friendly Cutlery" },
    { id: "custom", label: "Custom Requirements" },
  ];

  const volumes = [
    { value: "small", label: "1-10 tons" },
    { value: "medium", label: "10-50 tons" },
    { value: "large", label: "50-100 tons" },
    { value: "enterprise", label: "100+ tons" },
  ];

  if (showSuccess) {
    return (
      <section className="pt-20 pb-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="p-8 border border-border shadow-lg" data-testid="card-success">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="text-accent text-2xl" />
              </div>
              <h1 className="text-3xl font-bold text-foreground mb-4" data-testid="text-success-title">
                Thank You for Your Interest!
              </h1>
              <p className="text-muted-foreground mb-6" data-testid="text-success-description">
                Your request has been received. Here's what happens next:
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center" data-testid="item-next-step-1">
                <Clock className="text-primary mr-3 h-5 w-5" />
                <span className="text-muted-foreground">Our team will review your requirements within 24 hours</span>
              </div>
              <div className="flex items-center" data-testid="item-next-step-2">
                <Phone className="text-primary mr-3 h-5 w-5" />
                <span className="text-muted-foreground">A dedicated account manager will contact you to discuss details</span>
              </div>
              <div className="flex items-center" data-testid="item-next-step-3">
                <File className="text-primary mr-3 h-5 w-5" />
                <span className="text-muted-foreground">We'll provide customized quotations and partnership proposals</span>
              </div>
            </div>

            <Card className="p-4 bg-muted border border-border" data-testid="card-company-facts">
              <h3 className="font-semibold text-foreground mb-2">Quick Company Facts:</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Founded:</span>
                  <span className="text-foreground font-medium ml-2" data-testid="text-founded">London, UK</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Focus:</span>
                  <span className="text-foreground font-medium ml-2" data-testid="text-focus">B2B Trading</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Markets:</span>
                  <span className="text-foreground font-medium ml-2" data-testid="text-markets">Global</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Specialty:</span>
                  <span className="text-foreground font-medium ml-2" data-testid="text-specialty">Sustainable Products</span>
                </div>
              </div>
            </Card>

            <div className="text-center mt-8">
              <Button onClick={() => setShowSuccess(false)} data-testid="button-submit-another">
                Submit Another Request
              </Button>
            </div>
          </Card>
        </div>
      </section>
    );
  }

  return (
    <section className="pt-20 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-page-title">
            Get In Touch
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Ready to partner with us? Contact our team to discuss your trading requirements
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6" data-testid="text-contact-info-title">
              Contact Information
            </h2>
            
            <div className="space-y-6">
              <div className="flex items-start" data-testid="item-address">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mr-4">
                  <MapPin className="text-primary text-xl" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Head Office</h3>
                  <p className="text-muted-foreground">London, United Kingdom</p>
                </div>
              </div>

              <div className="flex items-start" data-testid="item-phone">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mr-4">
                  <Phone className="text-secondary text-xl" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Phone</h3>
                  <p className="text-muted-foreground">+44 7341698712</p>
                </div>
              </div>

              <div className="flex items-start" data-testid="item-email">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mr-4">
                  <Mail className="text-accent text-xl" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Email</h3>
                  <p className="text-muted-foreground">info@fourlionstrading.com</p>
                </div>
              </div>
            </div>

            {/* Global Presence */}
            <Card className="mt-8 bg-muted p-6" data-testid="card-global-markets">
              <h3 className="text-xl font-bold text-foreground mb-4">Global Markets</h3>
              <p className="text-muted-foreground mb-4">We serve wholesalers and distributors across:</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center">
                  <Check className="text-primary mr-2 h-4 w-4" />
                  <span className="text-muted-foreground">Asia</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-primary mr-2 h-4 w-4" />
                  <span className="text-muted-foreground">Middle East</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-primary mr-2 h-4 w-4" />
                  <span className="text-muted-foreground">Africa</span>
                </div>
                <div className="flex items-center">
                  <Check className="text-primary mr-2 h-4 w-4" />
                  <span className="text-muted-foreground">Europe</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Lead Generation Form */}
          <Card className="p-8 border border-border shadow-lg" data-testid="card-lead-form">
            <h2 className="text-2xl font-bold text-foreground mb-6" data-testid="text-form-title">
              Request Information
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name *</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            data-testid="input-first-name"
                            className="bg-background"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name *</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            data-testid="input-last-name"
                            className="bg-background"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Name *</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          data-testid="input-company"
                          className="bg-background"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Email *</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          {...field} 
                          data-testid="input-email"
                          className="bg-background"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          type="tel" 
                          {...field} 
                          data-testid="input-phone"
                          className="bg-background"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="country"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Country/Region *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-country" className="bg-background">
                            <SelectValue placeholder="Select Country" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {countries.map((country) => (
                            <SelectItem key={country.value} value={country.value}>
                              {country.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="products"
                  render={() => (
                    <FormItem>
                      <div className="mb-4">
                        <FormLabel className="text-base">Products of Interest *</FormLabel>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {products.map((product) => (
                          <FormField
                            key={product.id}
                            control={form.control}
                            name="products"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={product.id}
                                  className="flex flex-row items-start space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(product.id)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, product.id])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== product.id
                                              )
                                            )
                                      }}
                                      data-testid={`checkbox-product-${product.id}`}
                                    />
                                  </FormControl>
                                  <FormLabel className="text-sm font-normal">
                                    {product.label}
                                  </FormLabel>
                                </FormItem>
                              )
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="volume"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estimated Monthly Volume</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-volume" className="bg-background">
                            <SelectValue placeholder="Select Volume Range" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {volumes.map((volume) => (
                            <SelectItem key={volume.value} value={volume.value}>
                              {volume.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Requirements</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          rows={4}
                          placeholder="Tell us about your specific requirements, timeline, and any questions you have..."
                          data-testid="textarea-message"
                          className="bg-background"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={createLeadMutation.isPending}
                  data-testid="button-submit-request"
                >
                  {createLeadMutation.isPending ? "Submitting..." : "Submit Request"}
                </Button>
              </form>
            </Form>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Contact;
