import { Card } from "@/components/ui/card";
import { Eye, Compass, Heart, Trophy, Leaf, Users, CheckCircle } from "lucide-react";

const Vision = () => {
  const values = [
    {
      icon: Heart,
      title: "Integrity",
      description: "Conducting every transaction with honesty and transparency"
    },
    {
      icon: Trophy,
      title: "Excellence",
      description: "Consistently delivering superior quality and service"
    },
    {
      icon: Leaf,
      title: "Sustainability",
      description: "Promoting responsible sourcing and environmentally conscious practices"
    },
    {
      icon: Users,
      title: "Customer Focus",
      description: "Prioritising the needs of wholesalers and distributors"
    }
  ];

  const shortTermGoals = [
    "Establish strong market presence in Asia, Middle East, and Africa",
    "Secure long-term partnerships with wholesalers and distributors",
    "Expand product categories focusing on sustainable solutions"
  ];

  const longTermGoals = [
    "Diversify into Europe and North America markets",
    "Position as recognised global brand in trading industry",
    "Integrate sustainability practices across all operations"
  ];

  return (
    <section className="pt-20 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-page-title">
            Vision & Mission
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-page-subtitle">
            Our commitment to excellence, sustainability, and global partnerships
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          {/* Vision */}
          <Card className="p-8 border border-border" data-testid="card-vision">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <Eye className="text-primary text-2xl" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-4" data-testid="text-vision-title">Our Vision</h2>
            <p className="text-muted-foreground text-lg leading-relaxed" data-testid="text-vision-content">
              "To be a globally recognised trading partner, trusted for delivering quality, sustainable, and diverse products, while fostering growth, innovation, and integrity across international markets."
            </p>
          </Card>

          {/* Mission */}
          <Card className="p-8 border border-border" data-testid="card-mission">
            <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mb-6">
              <Compass className="text-accent text-2xl" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-4" data-testid="text-mission-title">Our Mission</h2>
            <p className="text-muted-foreground text-lg leading-relaxed" data-testid="text-mission-content">
              "Our mission is to connect global markets by supplying premium products. We are committed to ensuring uncompromising quality, sustainable sourcing, and efficient logistics, while building transparent, long-term relationships with wholesalers and distributors worldwide."
            </p>
          </Card>
        </div>

        {/* Core Values */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center text-foreground mb-8" data-testid="text-values-title">Our Core Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <div key={index} className="text-center" data-testid={`card-value-${value.title.toLowerCase()}`}>
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="text-primary text-xl" />
                </div>
                <h3 className="font-semibold text-foreground mb-2" data-testid={`text-value-title-${index}`}>
                  {value.title}
                </h3>
                <p className="text-sm text-muted-foreground" data-testid={`text-value-description-${index}`}>
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Business Objectives */}
        <div>
          <h2 className="text-2xl font-bold text-center text-foreground mb-8" data-testid="text-objectives-title">Business Objectives</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {/* Short-term Goals */}
            <Card className="bg-muted p-6" data-testid="card-short-term-goals">
              <h3 className="text-xl font-bold text-foreground mb-4" data-testid="text-short-term-title">
                Short-Term Goals (1-2 Years)
              </h3>
              <ul className="space-y-3">
                {shortTermGoals.map((goal, index) => (
                  <li key={index} className="flex items-start" data-testid={`item-short-term-${index}`}>
                    <CheckCircle className="text-primary mt-1 mr-3 h-4 w-4 flex-shrink-0" />
                    <span className="text-muted-foreground">{goal}</span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Long-term Goals */}
            <Card className="bg-muted p-6" data-testid="card-long-term-goals">
              <h3 className="text-xl font-bold text-foreground mb-4" data-testid="text-long-term-title">
                Long-Term Goals (5+ Years)
              </h3>
              <ul className="space-y-3">
                {longTermGoals.map((goal, index) => (
                  <li key={index} className="flex items-start" data-testid={`item-long-term-${index}`}>
                    <CheckCircle className="text-accent mt-1 mr-3 h-4 w-4 flex-shrink-0" />
                    <span className="text-muted-foreground">{goal}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Vision;
