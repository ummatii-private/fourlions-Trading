import { Card } from "@/components/ui/card";
import { Handshake, Shield, Package, Truck, Star } from "lucide-react";

const Overview = () => {
  const features = [
    {
      icon: Handshake,
      title: "Global Partnerships",
      description: "Building strong, transparent relationships with wholesalers worldwide"
    },
    {
      icon: Shield,
      title: "Quality Control",
      description: "Rigorous checks to comply with international standards"
    },
    {
      icon: Package,
      title: "Complete Portfolio",
      description: "From staple foods to sustainable alternatives"
    },
    {
      icon: Truck,
      title: "Efficient Logistics",
      description: "Streamlined supply chain for on-time deliveries"
    },
    {
      icon: Star,
      title: "Integrity",
      description: "Built upon trust, transparency, and excellence"
    }
  ];

  return (
    <section className="pt-20 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-page-title">
            Company Overview
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-page-subtitle">
            A growing international import-export company dedicated to delivering high-quality products and building long-lasting relationships worldwide.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Modern office building representing international trade" 
              className="rounded-xl shadow-lg w-full h-auto"
              data-testid="img-office-building"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-4" data-testid="text-about-title">
              About Fourlions Trading Limited
            </h2>
            <p className="text-muted-foreground mb-6" data-testid="text-about-description-1">
              Headquartered in London, we act as a trusted bridge between producers and markets, ensuring that essential commodities reach customers across borders with efficiency and reliability.
            </p>
            <p className="text-muted-foreground mb-6" data-testid="text-about-description-2">
              Our multi-category product portfolio allows wholesalers to source from a single trusted partner, saving time whilst ensuring consistency in quality.
            </p>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-center text-foreground mb-8" data-testid="text-features-title">
            What Sets Us Apart
          </h2>
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-8">
            {features.map((feature, index) => (
              <Card 
                key={index}
                className="p-6 border border-border card-hover"
                data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="text-primary text-xl" />
                </div>
                <h3 className="font-semibold text-foreground mb-2" data-testid={`text-feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground" data-testid={`text-feature-description-${index}`}>
                  {feature.description}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Overview;
